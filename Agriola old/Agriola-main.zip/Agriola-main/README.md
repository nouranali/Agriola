# Agriola 
## Agriola is an AI powered agricultural website that provides many services and features based on remote sensing and satellite imagery
## documentation to be added
