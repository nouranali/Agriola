// AUTOMATICALLY GENERATED: imported vars from saved link.
var CONVERT_TO_IMPORT = (
[{"type":"geometry","name":"roi","record":{"geometries":[{"type":"Polygon","coordinates":
       [[[31.515837951936703,31.22334937033621],
         [31.136809631624203,31.228046749775867],
         [31.268645569124203,30.931656697010993],
         [31.620208069124203,30.865666902630277]]],"evenOdd":true}],
 "displayProperties":[],"properties":{},"color":"#d63000","mode":"Geometry","shown":true,"locked":false}},
 {"type":"image","name":"gfc2019","record":{"id":"UMD/hansen/global_forest_change_2019_v1_7"}}])

// AUTOMATICALLY GENERATED: location from saved link.
Map.setCenter(264.8, 34.8, 4)
//use landsat8 for analysis 
var l8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
.filter(ee.Filter.lt('CLOUD_COVER',5))
.filterDate('1984-01-01','2020-12-31');

//compute ndvi to determined the green of this region 
var addNDVI= function(image) {
  var ndvi = image.normalizedDifference(['B5', 'B4']).rename('NDVI');
  return image.addBands(ndvi);
};
var withNDVI = l8.map(addNDVI);
var chart = ui.Chart.image.series({
  imageCollection: withNDVI.select('NDVI'),
  region: roi  //region of interest ,
  reducer: ee.Reducer.first(),
  scale: 30
}).setOptions({title: 'NDVI over time'});
print(chart,'An NDVI value of zero means no green vegetation'
,'An NDVI value of close to +1 (0.8 - 0.9) indicates the highest possible density of green leaves');
var image = ee.Image(
  withNDVI.filterBounds(roi)
    .first()
);

var ndvi=image.select('NDVI');
var ndviParams = {min: -1,  max:0.8, palette:["red", "orange", "yellow", "green"]};
Map.addLayer(ndvi, ndviParams, 'NDVI');
Map.addLayer(ndvi.gt([0, 0.2, 0.40, 0.60, 0.80]).reduce('sum'), {min:0, max: 4, palette: ["red", "orange", "yellow", "green", "darkgreen"]}, "NDVI steps")


//compute loss of vegetation area using 
//hansen global_forest_change_2019_v1_7
var lossImage = gfc2019.select(['loss']);
var lossAreaImage = lossImage.multiply(ee.Image.pixelArea());

var lossYear = gfc2019.select(['lossyear']);
var lossByYear = lossAreaImage.addBands(lossYear).reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1
    }),
  geometry: roi,
  scale: 30,
  maxPixels: 1e9,
  bestEffort:true
});
print(lossByYear);
var statsFormatted = ee.List(lossByYear.get('groups'))
  .map(function(el) {
    var d = ee.Dictionary(el);
    return [ee.Number(d.get('group')).format("20%02d"), d.get('sum')];
  });
var statsDictionary = ee.Dictionary(statsFormatted.flatten());
print(statsDictionary);
var chart = ui.Chart.array.values({
  array: statsDictionary.values(),
  axis: 0,
  xLabels: statsDictionary.keys()
}).setChartType('ColumnChart')
  .setOptions({
    title: 'Yearly Vegetation Loss',
    hAxis: {title: 'Year', format: '####'},
    vAxis: {title: 'Area (square meters)'},
    legend: { position: "none" },
    lineWidth: 1,
    pointSize: 3
  });
print(chart);
var total_loss = lossImage.reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: roi,
  scale: 30,
  maxPixels: 1e9
});
print(tota_loss);
