//imports :
var CONVERT_TO_IMPORT = (
[{"type":"geometry","name":"roi","record":{"geometries":[{"type":"Polygon","coordinates":[[[31.675049953271973,30.636031595357682],[31.74636290864416,31.210252866723348],[31.581764075007182,31.315772422359913],[30.863025060462768,31.172702609729395],[30.67099403952902,31.139839235567248],[30.753285457725852,30.80112083955653]]],"geodesic":true,"evenOdd":true}],"displayProperties":[],"properties":{},"color":"#d63000","mode":"Geometry","shown":true,"locked":false}},{"type":"image","name":"gsw","record":{"id":"JRC/GSW1_2/GlobalSurfaceWater"}}])


Map.setCenter(31.070364682216614, 30.984283093247804, 11)

//////////////////////////////////////////////////////////////
// Asset List
//////////////////////////////////////////////////////////////

var occurrence = gsw.select('occurrence');
var change = gsw.select("change_abs");


//////////////////////////////////////////////////////////////
// Constants
//////////////////////////////////////////////////////////////

var VIS_OCCURRENCE = {
    min:0,
    max:100,
    palette: ['red', 'blue']
};
var VIS_CHANGE = {
    min:-50,
    max:50,
    palette: ['red', 'black', 'limegreen']
};
var VIS_WATER_MASK = {
  palette: ['white', 'black']
};

//////////////////////////////////////////////////////////////
// Calculations
//////////////////////////////////////////////////////////////

// Create a water mask layer, and set the image mask so that non-water areas are transparent.
var water_mask = occurrence.gt(90).mask(1);

// Generate a histogram object and print it to the console tab.
var histogram = ui.Chart.image.histogram({
  image: change,
  region: roi,
  scale: 30,
  minBucketWidth: 10,

});
histogram.setOptions({
  title: 'Histogram of surface water change intensity.'
});
print(histogram);

//////////////////////////////////////////////////////////////
// Initialize Map Location
//////////////////////////////////////////////////////////////

Map.setCenter(31.070364682216614,30.984283093247804, 11);  // egypt
//////////////////////////////////////////////////////////////
// Map Layers
//////////////////////////////////////////////////////////////

Map.addLayer({
  eeObject: water_mask,
  visParams: VIS_WATER_MASK,
  name: '90% occurrence water mask',
  shown: false
});
Map.addLayer({
  eeObject: occurrence.updateMask(occurrence.divide(100)),
  name: "Water Occurrence (1984-2019)",
  visParams: VIS_OCCURRENCE,
  shown: false
});
Map.addLayer({
  eeObject: change,
  visParams: VIS_CHANGE,
  name: 'occurrence change intensity'
});
